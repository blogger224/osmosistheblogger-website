import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
data = {
    "state": ["Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia",
              "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland",
              "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey",
              "New Mexico", "New York", "N. Carolina", "N. Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "S. Carolina",
              "S. Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "W. Virginia", "Wisconsin", "Wyoming"],
    "state2": ["AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA",
               "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD",
               "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ",
               "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC",
               "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"],
    "region": ["South", "West", "West", "South", "West", "West", "NE", "South", "South", "South",
               "West", "West", "N Cntrl", "N Cntrl", "N Cntrl", "N Cntrl", "South", "South", "NE", "South",
               "NE", "N Cntrl", "N Cntrl", "South", "N Cntrl", "West", "N Cntrl", "West", "NE", "NE",
               "West", "NE", "South", "N Cntrl", "N Cntrl", "South", "West", "NE", "NE", "South",
               "N Cntrl", "South", "South", "West", "NE", "South", "West", "South", "N Cntrl", "West"],
    "pop": [3893888, 401851, 2718215, 2286435, 23667902, 2889964, 3107576, 594338, 9746324, 5463105,
            964691, 943935, 11426518, 5490224, 2913808, 2363679, 3660777, 4205900, 1124660, 4216975,
            5737037, 9262078, 4075970, 2520638, 4916686, 786690, 1569825, 800493, 920610, 7364823,
            1302894, 17558072, 5881766, 652717, 10797630, 3025290, 2633105, 11863895, 947154, 3121820,
            690768, 4591120, 14229191, 1461037, 511456, 5346818, 4132156, 1949644, 4705767, 469557],
    "poplt5": [296412, 38949, 213883, 175592, 1708400, 216495, 185188, 41151, 570224, 414935,
               77848, 93531, 842241, 418764, 221628, 180877, 282731, 361533, 78514, 272274,
               337215, 685113, 307249, 215279, 354144, 64455, 122946, 56132, 62512, 463289,
               114731, 1135925, 404076, 54752, 787150, 233307, 198046, 747458, 56692, 238516,
               58446, 326088, 1169061, 189962, 35998, 360686, 306123, 145583, 346940, 44845],
    "pop5_17": [865836, 91796, 577604, 495782, 4680558, 592318, 637731, 125444, 1789412, 1231195,
                197735, 213134, 2400796, 1199554, 604245, 468158, 799999, 968935, 242873, 895256,
                1153174, 2066873, 864559, 598918, 1008339, 167440, 324224, 159667, 195570, 1527572,
                303176, 3551938, 1253659, 136239, 2307170, 621577, 525011, 2375838, 186159, 703450,
                147160, 972472, 3137045, 350143, 109320, 1113648, 833237, 414053, 1010880, 100708],
    "pop18p": [2731640, 271106, 1926728, 1615061, 17278944, 2081151, 2284657, 427743, 7386688, 3816975,
               689108, 637270, 8183481, 3871906, 2087935, 1714644, 2578047, 2875432, 803273, 3049445,
               4246648, 6510092, 2904162, 1706441, 3554203, 554795, 1122655, 584694, 662528, 5373962,
               884987, 12870209, 4224031, 461726, 7703310, 2170406, 1910048, 8740599, 704303, 2179854,
               485162, 3292560, 9923085, 920932, 366138, 3872484, 2992796, 1390008, 3347947, 324004],
    "pop65p": [440015, 11547, 307362, 312477, 2414250, 247325, 364864, 59179, 1687573, 516731,
               76150, 93680, 1261885, 585384, 387584, 306263, 409828, 404279, 140918, 395609,
               726531, 912258, 479564, 289357, 648126, 84559, 205684, 65756, 102967, 859771,
               115906, 2160767, 603181, 80445, 1169460, 376126, 303336, 1530933, 126922, 287328,
               91019, 517588, 1371161, 109220, 58166, 505304, 431562, 237868, 564197, 37175],
    "popurban": [2337713, 258567, 2278728, 1179556, 21607606, 2329869, 2449774, 419819, 8212385, 3409081,
                 834592, 509702, 9518039, 3525298, 1708232, 1575899, 1862183, 2887309, 534072, 3386555,
                 4808339, 6551551, 2725202, 1192805, 3349588, 416402, 987859, 682947, 480325, 6557377,
                 939963, 14858068, 2822852, 318310, 7918259, 2035082, 1788354, 8220851, 824004, 1689253,
                 320777, 2773573, 11333017, 1233060, 172735, 3529423, 3037014, 705319, 3020732, 294639],
    "medage": [29.3, 26.1, 29.2, 30.6, 29.9, 28.6, 32, 29.8, 34.7, 28.7,
               28.4, 27.6, 29.9, 29.2, 30, 30.1, 29.1, 27.4, 30.4, 30.3,
               31.2, 28.8, 29.2, 27.7, 30.9, 29, 29.7, 30.2, 30.1, 32.2,
               27.4, 31.9, 29.6, 28.3, 29.9, 30.1, 30.2, 32.1, 31.8, 28.1,
               28.9, 30.1, 28.2, 24.2, 29.4, 29.8, 29.8, 30.4, 29.4, 27.1],
    "death": [35305, 1604, 21226, 22676, 186428, 18925, 26005, 5123, 104190, 44230,
              4849, 6753, 102230, 47300, 26348, 21910, 33765, 35518, 10768, 34025,
              54919, 75102, 33412, 23570, 49329, 6664, 14465, 5852, 7594, 68762,
              9016, 171769, 48426, 5596, 98268, 28227, 21756, 123261, 9300, 25138,
              6523, 40713, 108019, 8103, 4587, 42496, 32012, 19186, 39255, 3215],
    "marriage": [49018, 5361, 30223, 26513, 210864, 34917, 26048, 4437, 108344, 70638,
                 11856, 13428, 109823, 57853, 27474, 24847, 32727, 43460, 12040, 46278,
                 46273, 86898, 37641, 27908, 54625, 8336, 14239, 114333, 9251, 55794,
                 16641, 144518, 46718, 6094, 99832, 46509, 23004, 93673, 7490, 53915,
                 8800, 59175, 181762, 16958, 5226, 60210, 47728, 17391, 41111, 6868],
    "divorce": [26745, 3517, 19908, 15882, 133541, 18571, 13488, 2313, 71579, 34743,
                4438, 6596, 50997, 40006, 11854, 13410, 16731, 18108, 6205, 17494,
                17873, 45047, 15371, 13846, 27595, 4940, 6442, 13842, 5254, 27796,
                10426, 61972, 28050, 2142, 58809, 24226, 17762, 34922, 3606, 13595,
                2811, 30206, 96809, 7802, 2623, 23615, 28642, 10273, 17546, 4003]
}

df = pd.DataFrame(data)

# 1. What is average population in the dataset?
average_population = df['pop'].mean()
print(f"The average population is {average_population:.2f}")

# 2. Which five states have the highest divorce rates?
highest_divorce_rates = df.nlargest(5, 'divorce')
print("The five states with the highest divorce rates are:")
print(highest_divorce_rates[['state', 'divorce']])

# 3. Which five states have the highest marriage rates?
highest_marriage_rates = df.nlargest(5, 'marriage')
print("The five states with the highest marriage rates are:")
print(highest_marriage_rates[['state', 'marriage']])

# 4. Draw a bar graph for the average population for the regions in the dataset
avg_population_region = df.groupby('region')['pop'].mean().reset_index()

plt.figure(figsize=(10, 6))
sns.barplot(x='region', y='pop', data=avg_population_region)
plt.title('Average Population by Region')
plt.xlabel('Region')
plt.ylabel('Average Population')
plt.show()

# 5. Using a grouped bar graph, show the average median age, urban population, marriage rates and divorce rates for the East and West regions.
east_west_data = df[df['region'].isin(['NE', 'West'])].groupby(
    'region').mean().reset_index()

melted_data = east_west_data.melt(id_vars='region', value_vars=[
                                  'medage', 'popurban', 'marriage', 'divorce'], var_name='Metric', value_name='Value')

plt.figure(figsize=(12, 8))
sns.barplot(x='Metric', y='Value', hue='region', data=melted_data)
plt.title('Average Median Age, Urban Population, Marriage Rates, and Divorce Rates for East and West Regions')
plt.xlabel('Metric')
plt.ylabel('Average Value')
plt.legend(title='Region')
plt.show()
